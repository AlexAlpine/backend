package org.demo47fsupload.controller;

import lombok.RequiredArgsConstructor;
import org.demo47fsupload.service.CategoryImageService;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/image/category")
public class CategoryImageController {
    private final CategoryImageService service;

    @GetMapping("/{filename}")
    public ResponseEntity<Resource> getCategoryImage(@PathVariable String filename) {
        Resource image = service.loadCategoryImage(filename);

        // определим тип содержимого как изображение

        MediaType mediaType = MediaType.IMAGE_JPEG;

        // необходимо создать заголовок для ответа

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(mediaType);

        // надо установить заголовок Content - Disposition чтобы браузер
        // знал что делать с содержимым нашего ответа (по умолчанию - сохраняет на диск)

        headers.setContentDispositionFormData("inline",filename);

        // возвращем ответ с байтами изображения, заголовком и статусом

        return ResponseEntity.ok()
                .headers(headers)
                .body(image);
    }
}
