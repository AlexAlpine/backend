package org.demo47fsupload;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Demo47fsUploadApplicationTests {

    @Test
    void contextLoads() {
    }

}
