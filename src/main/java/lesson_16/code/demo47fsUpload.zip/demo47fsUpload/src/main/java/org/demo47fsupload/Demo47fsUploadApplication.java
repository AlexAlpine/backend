package org.demo47fsupload;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Demo47fsUploadApplication {

    public static void main(String[] args) {
        SpringApplication.run(Demo47fsUploadApplication.class, args);
    }

}
