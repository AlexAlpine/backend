package org.basicCourse.javaInputOutput;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class FileCopeExample {
    public static void main(String[] args) {

        try {
            copyFile("src/main/java/org/basicCourse/javaInputOutput/","pic1.jpeg","pic1_copy.jpeg");
        } catch (IOException e){
            System.out.println(e.getMessage());
        }
    }

    public static void copyFile(String path, String fileSource, String fileDestination) throws IOException {
        FileOutputStream outputStream = new FileOutputStream(path + fileDestination);
        FileInputStream inputStream = new FileInputStream(path + fileSource);

        int readByte;

        do {
            readByte = inputStream.read();
            if (readByte >= 0) outputStream.write(readByte);
        } while (readByte != -1);

        inputStream.close();
        outputStream.close();

    }
}
