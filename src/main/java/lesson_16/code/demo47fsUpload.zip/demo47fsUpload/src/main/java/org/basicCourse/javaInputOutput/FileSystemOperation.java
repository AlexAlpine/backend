package org.basicCourse.javaInputOutput;

import java.io.File;
import java.util.Arrays;

public class FileSystemOperation {
    public static void main(String[] args) {

        File file = new File("test.txt");

        boolean isExist = file.exists();

        System.out.println("Does file exist? " + isExist);

        // ------ создать директорию (папку) -----


        File dir = new File("new_dir");
        boolean wasCreate = dir.mkdir();
        System.out.println("Directory was create? " + wasCreate);

        // ----- проверим что это именно директория а не файл

        File directory = new File("new_dir");
        boolean isDir = directory.isDirectory();
        System.out.println(isDir);

        // --- удалим директорию

//        boolean successDelete = directory.delete();
//        System.out.println(successDelete);

        // --- посмотреть содержимое директорий

        String[] filenames = directory.list();

        System.out.println(Arrays.toString(filenames));

        File[] files = directory.listFiles();

        System.out.println(Arrays.toString(files));


    }
}
