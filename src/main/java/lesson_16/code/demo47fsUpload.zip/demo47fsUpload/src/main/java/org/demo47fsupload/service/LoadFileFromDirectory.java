package org.demo47fsupload.service;

import lombok.extern.slf4j.Slf4j;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.stereotype.Service;

import java.net.MalformedURLException;
import java.nio.file.Path;
import java.nio.file.Paths;

@Service
@Slf4j
public class LoadFileFromDirectory {

    //private final Path fileSourceLocation = Paths.get("src/main/resources/static/files/");


    public Resource loadFileFromDirectory(String directory, String filename){

        try {
            Path filepath = Paths.get("src/main/resources/static/files/" + directory).resolve(filename).normalize();

            Resource resource = new UrlResource(filepath.toUri());

            log.info("filepath {}", filepath);
            log.info("resource {}", resource);


            if (resource.exists() && resource.isReadable()) {
                return resource;
            }  else {
                throw new RuntimeException("Файл не найден: " + filename);
            }
        } catch (MalformedURLException e) {
            throw new RuntimeException("Ошибка при загрузке файла: " + filename);
        }
    }
}
