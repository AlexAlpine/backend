package org.basicCourse.javaInputOutput;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class FileWriterAndReader {
    public static void main(String[] args) throws IOException {

        writeText("fileWriteDemo.txt");
        readText("fileWriteDemo.txt");
    }

    public static void writeText(String path) throws IOException {
        FileWriter writer = new FileWriter(path);
        writer.write("Привет! как дела?");
        writer.close();
    }

    public static void readText(String path) throws IOException {
        FileReader reader = new FileReader(path);

        int character;

        while ((character = reader.read()) != -1){
            System.out.print((char) character);
        }
    }

}
