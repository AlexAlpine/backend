package org.basicCourse.javaInputOutput;

import java.io.*;

public class FileOutputInputStreamExample {
    public static void main(String[] args) throws IOException {
        output("test_stream.txt");
        input("test_stream.txt");

    }

    public static void output(String path) throws IOException {

            FileOutputStream outputStream = new FileOutputStream(path);
            outputStream.write("привет, как дела?".getBytes());
            outputStream.close();
    }

    public static void input(String path) throws IOException {
        FileInputStream inputStream = new FileInputStream(path);

        int data = inputStream.read();

        while (data != -1){
            System.out.print((char)data + " ");
            data = inputStream.read();
        }

        inputStream.close();
    }
}
