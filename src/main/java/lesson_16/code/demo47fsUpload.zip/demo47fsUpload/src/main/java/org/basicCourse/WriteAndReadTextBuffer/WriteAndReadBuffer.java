package org.basicCourse.WriteAndReadTextBuffer;

import java.io.*;

public class WriteAndReadBuffer {
    public static void main(String[] args) throws IOException {

      String path = "writeExample.txt";

      writeBufferFile(path);
      readerBufferFile(path);

    }

    public static void writeBufferFile(String path) throws IOException {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(path));
        bufferedWriter.write("Hello, World! \n");
        bufferedWriter.newLine();
        bufferedWriter.newLine();
        bufferedWriter.write("как дела?");
        bufferedWriter.newLine();
        bufferedWriter.write("все отлично! \n");
        bufferedWriter.close();
    }

    public static void readerBufferFile(String path) throws IOException {
        BufferedReader bufferedReader = new BufferedReader(new FileReader(path));

        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter("writeExample2.txt"));

        String line;

        while ((line = bufferedReader.readLine()) != null) {
            System.out.println(line);
            bufferedWriter.write(line);
            bufferedWriter.newLine();
        }

        bufferedReader.close();
        bufferedWriter.close();

    }

}
