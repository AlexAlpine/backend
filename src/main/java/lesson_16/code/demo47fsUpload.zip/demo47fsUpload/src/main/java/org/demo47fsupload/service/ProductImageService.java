package org.demo47fsupload.service;

import lombok.RequiredArgsConstructor;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class ProductImageService {

    private final LoadFileFromDirectory lfd;

    public Resource loadCategoryImage(String filename){
        return lfd.loadFileFromDirectory("product_img",filename);
    }
}
